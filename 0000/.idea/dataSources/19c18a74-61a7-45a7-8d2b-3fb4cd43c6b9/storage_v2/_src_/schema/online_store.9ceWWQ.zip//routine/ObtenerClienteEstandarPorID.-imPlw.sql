create
    definer = root@localhost procedure ObtenerClienteEstandarPorID(IN cliente_id int, OUT encontrado int)
BEGIN
    DECLARE num_rows INT;

    -- Contar las filas que coinciden usando la columna correcta (idCliente)
    SELECT COUNT(*) INTO num_rows
    FROM clienteEstandar
    WHERE idCliente = cliente_id;

    IF num_rows > 0 THEN
        SELECT *
        FROM cliente
        WHERE idCliente = cliente_id;
        SET encontrado = num_rows;
    ELSE
        SET encontrado = 0;
    END IF;
END;

