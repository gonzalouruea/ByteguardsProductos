create
    definer = root@localhost procedure insertarClientePremium(IN p_nombre varchar(40), IN p_domicilio varchar(40),
                                                              IN p_nif varchar(40), IN p_email varchar(40),
                                                              IN p_descuento float)
BEGIN
    INSERT INTO cliente (nombre, domicilio, nif, email)
    VALUES (p_nombre, p_domicilio, p_nif, p_email);

    SET @last_id = LAST_INSERT_ID();

    INSERT INTO clientePremium (idCliente, descuento) VALUES (@last_id, p_descuento);
END;

