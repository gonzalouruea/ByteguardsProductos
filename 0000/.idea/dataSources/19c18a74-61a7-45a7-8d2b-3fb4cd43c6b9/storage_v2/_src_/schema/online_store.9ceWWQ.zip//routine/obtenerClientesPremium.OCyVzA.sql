create
    definer = root@localhost procedure obtenerClientesPremium()
BEGIN
    SELECT *
    FROM cliente
    INNER JOIN clientePremium ON cliente.idCliente = clientePremium.idCliente;
END;

