create
    definer = root@localhost procedure obtenerClientesEstandar()
BEGIN
    SELECT *
    FROM cliente
    INNER JOIN clienteEstandar ON cliente.idCliente = clienteEstandar.idCliente;
END;

