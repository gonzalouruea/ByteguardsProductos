create
    definer = root@localhost procedure insertarClienteEstandar(IN p_nombre varchar(40), IN p_domicilio varchar(40),
                                                               IN p_nif varchar(40), IN p_email varchar(40))
BEGIN
    -- Insertar en la tabla cliente y obtener el id generado
    INSERT INTO cliente (nombre, domicilio, nif, email)
    VALUES (p_nombre, p_domicilio, p_nif, p_email);

    SET @last_id = LAST_INSERT_ID();

    -- Insertar en clienteEstandar usando el id generado
    INSERT INTO clienteEstandar (idCliente) VALUES (@last_id);
END;

